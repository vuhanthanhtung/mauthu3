<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users_laravel extends Model
{
	//
       protected $fillable = ['username', 'password'];

}
