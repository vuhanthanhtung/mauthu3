<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Information ;
class Information_controller extends Controller
{
    public function getquery(){
        return view('query');
    }

    public function postquery(Request $request){
	$number = $request->post('number');
	
        if ($number == 1){
                $users = Information::All()->toArray();
	}
	if ($number == 2){
		$users = Information::where('isStudent', '=', 'Yes')->get();
	}
	if ($number == 3){
		$users = (new Information)->where('Lastname', 'Nguyen')->orWhere("FirstName", 'vu')->get();
	}
	if ($number == 4){
		$users = (new Information)->select('id','FirstName')->get();
	}
	if ($number == 5){
		$users = Information::max('Number');
		dd($users);
	}
	if ($number == 6){
		$users = (new Information)->first();
		dd($users);
	}
	if ($number == 7){
		$users = Information::where('Number', '>=', '5000')->get();
	}
	if ($number == 8){
		$users = (new Information)->where('Lastname', 'Hoang')->avg('Number');
	       dd($users);	
        }
	if ($number == 9){
		$users = Information::count();
		dd($users);
	}
	if ($number == 10){
                $users = Information::where('isStudent', 'Yes')->where('Number', '<', '8000')-> orderBy('id', 'desc')->limit(2)->get();
        }

        return view('users_laravel.index', compact('users'));

    }

}
