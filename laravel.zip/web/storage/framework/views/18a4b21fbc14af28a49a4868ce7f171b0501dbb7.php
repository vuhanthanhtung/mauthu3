<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<br />
		<h3 align="left"> Users Data </h3>
		<br />
		<table class="table table-bordered">
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($row['id']); ?></td>
				<td></td>
				<td><?php echo e($row['FirstName']); ?></td>
				<td><?php echo e($row['LastName']); ?></td>
				<td></td>
				<td></td>
				<td><?php echo e($row['Email']); ?></td>
				<td></td>
				<td><?php echo e($row['Phone']); ?></td>
				<td></td>
				<td></td>
				<td><?php echo e($row['isStudent']); ?></td>
				<td></td>
				<td></td>

                                <td><?php echo e($row['Number']); ?></td>
				<td></td>
				<td></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/web/resources/views/users_laravel/index.blade.php ENDPATH**/ ?>