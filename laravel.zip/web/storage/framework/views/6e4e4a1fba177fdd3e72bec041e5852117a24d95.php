<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
	<br />
	<h3 aling="center">Add Data</h3>
	<br />
	<form method="post" action="<?php echo e(url('query')); ?>">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<input type="text" name="number" class="form-control" placeholder="Enter number"/>
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control" placeholder="Enter your Password"/>
		</div>
		<div class="form-group">
			<input type="submit" class="btn btn-primary"/>
		</div>

	</form>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/web/resources/views/query.blade.php ENDPATH**/ ?>