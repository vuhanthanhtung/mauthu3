@extends('layouts.master')
@section('content')
<div class="row">
	<div class="col-md-12">
		<br />
		<h3 align="left"> Users Data </h3>
		<br />
		<table class="table table-bordered">
			@foreach($users as $row)
			<tr>
				<td>{{$row['id']}}</td>
				<td></td>
				<td>{{$row['FirstName']}}</td>
				<td>{{$row['LastName']}}</td>
				<td></td>
				<td></td>
				<td>{{$row['Email']}}</td>
				<td></td>
				<td>{{$row['Phone']}}</td>
				<td></td>
				<td></td>
				<td>{{$row['isStudent']}}</td>
				<td></td>
				<td></td>

                                <td>{{$row['Number']}}</td>
				<td></td>
				<td></td>
			</tr>
			@endforeach
		</table>
	</div>
</div>
@endsection
