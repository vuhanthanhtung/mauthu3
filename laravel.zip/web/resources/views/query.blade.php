@extends('layouts.master')
@section('content')
<div class="row">
	<div class="col-md-12">
	<br />
	<h3 aling="center">Add Data</h3>
	<br />
	<form method="post" action="{{url('query')}}">
		{{csrf_field()}}
		<div class="form-group">
			<input type="text" name="number" class="form-control" placeholder="Enter number"/>
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control" placeholder="Enter your Password"/>
		</div>
		<div class="form-group">
			<input type="submit" class="btn btn-primary"/>
		</div>

	</form>
</div>

@endsection

